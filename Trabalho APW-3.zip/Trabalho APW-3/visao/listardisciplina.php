<!DOCTYPE html>
<?php
    require '../modelo/classusuario.php';
    require '../modelo/DAO/classusuarioDAO.php';

    $classUsuarioDAO = new ClassUsuarioDAO();
    $us = $classUsuarioDAO->listarCursos();

    echo "<table class='table'>";
    echo "  <tr class='cor-fundo'>";
    echo "      <th scope='col' class='fonte cor-segunda'><p align='center'>Nome</p></th> ";
    echo "      <th scope='col' class='fonte cor-segunda'><p align='center'>Descricao</p></th> ";
    echo "  <tr>";

    foreach ($us as $us) {
        echo "<tr>";
        echo "<td scope='col' class='fonte'><p align='center'>" . $us['nome'] . "</p></td>";
        echo "<td scope='col' class='fonte'><p align='center'>" . $us['descricao'] . "</p></td>";
        echo "</tr>";
    }
    ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style> .fonte{
    font-family: 'Pacifico', cursive;
   }
   </style>
   <style>
       .cor-segunda{
      color: darkolivegreen;}
       .cor-fundo{
        background-color: lemonchiffon;
       
       }
    </style>
   
<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Castelinho kids</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <style> .fonte{
    font-family: 'Pacifico', cursive;
   }
   </style>
    <style>

    .cor{
       color:white;
    }
    .cor-segunda{
      color: darkolivegreen !important;;
      
    }
    .cor-botao-especial{
      background-color: darkolivegreen;
      color:white;
    }
    .border-cor-especial{
      border-color: darkolivegreen;

    }
    .card-posicao-imagem{
      object-fit: cover;
      height: 200px;

    }
    .card-largura{
      max-width: 18rem; 
    }
    .imagem-carrossel1{
      object-position: 0% 80%;
      object-fit: cover;
      height: 400px;

    }
    .imagem-carrossel2{

     object-position: 30% 100%;
      object-fit: cover;
      height: 400px;
    }
    .fonte-titulo{
      font-family: 'Pacifico', cursive;

    }
  </style>
</head>

<body>

<header>
  <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <a class="navbar-brand fonte-titulo cor-segunda" href="#">Castelinho kids</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item active">
          <a class="nav-link fonte cor-segunda" href="#">Início<span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link fonte cor-segunda" data-toggle="modal" data-target="#modal-contato" href="#">Cadastro Aluno</a>
        </li>
        <li class="nav-item">
          <a class="nav-link fonte cor-segunda" data-target="#modal-contato" href="cadastro2.php">Cadastro Professor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link fonte cor-segunda"  data-target="#modal-contato" href="cadastro3.php">Cadastro Curso</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle fonte cor-segunda" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Informações
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item fonte cor-segunda" href="listaraluno.php">Alunos</a> 
            <a class="dropdown-item fonte cor-segunda" href="listarprofessor.php">Professores</a>
            <a class="dropdown-item fonte cor-segunda" href="listardisciplina.php">diciplinas</a>
          </div>
        </li>
      </ul>
    </div>
  </nav>
  </header>

  <main>
  <title>Castelinho kids</title>
 
  <sect class="bd-example">
    <div id="carouselExampleCaptions" class="carousel slide"  data-interval="5000" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      </ol>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="img/alunos.jpg" class="d-block w-100 imagem-carrossel1" alt="...">
          <div class="carousel-caption d-none d-md-block h-50 ">
            <h1 class="fonte display-4 cor">Escola que acolhe,educação que transforma! </h1>
          </div>
        </div>
        <div class="carousel-item">
          <img src="img/quadro1.jpeg" class="d-block w-100 imagem-carrossel2" alt="...">
          <div class="carousel-caption d-none d-md-block h-50 ">
            <h1 class="fonte display-4 cor">A educação é o caminho para crescer!</h1>
          </div>
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </section>
  <section id="titulo">
  <h1 class="text-center fonte display-4 cor-segunda pt-5">Castelinho kids</h1>
  <p class="text-center text-secondary pb-5">Nossas atividades pedagógica consiste em ajudar a criança a avançar no caminho da independência, dando asas para que ela seja o que quiser.</p>
  </section>

  <section class="container" id="cartazes">
    <div class="row justify-content-center">
    <article class="card border-cor-especial card-largura p-0 m-4 col-12 col-md-4 ">
    <img src="img/alunos2.jpg" class="card-img-top card-posicao-imagem" alt="...">
    <div class="card-body">
      <h5 class="card-title fonte cor-segunda">Nossos profissionais</h5>
      <p>Nossos profissionais extremamente qualificados, ajudam sua criança a desenvolver com atenção especial e carinho!</p>
    </div>
  </article>

  <article class="card border-cor-especial card-largura p-0 m-4 col-12 col-md-4">
    <img src="img/professionais 3.jpg" class="card-img-top card-posicao-imagem" alt="...">
    <div class="card-body">
      <h5 class="card-title fonte cor-segunda">Alunos</h5>
      <p class="card-text">É dos sonhos que nasce a inteligência, com amor e dedicação trabalhamos com nossos alunos.</p>
    </div>
  </article>

  <article class="card border-cor-especial card-largura p-0 m-4 col-12 col-md-4">
    <img src="img/disciplinas2.jpg" class="card-img-top card-posicao-imagem" alt="...">
    <div class="card-body">
      <h5 class="card-title fonte cor-segunda">Disciplinas</h5>
      <p class="card-text">Com diferentes teorias e abordagens desenvolvemos uma grade de disciplinas específicas para desenvolver a capacidade de consciência e responsabilidade.</p>
    </div>
  </article>

  <article class="card border-cor-especial card-largura p-0 m-4 col-12 col-md-4 ">
    <img src="img/brinquedoteca.jpg" class="card-img-top card-posicao-imagem" alt="...">
    <div class="card-body">
      <h5 class="card-title fonte cor-segunda">Brinquedoteca</h5>
      <p class="card-text">Espaço desenvolvido com jogos, brinquedos e instrumentos para desenvolver a ludicidade da criança, podendo ser utilizado de forma livre e com o auxílio dos nosso profissionais.</p>
    </p>
    </div>
  </article>

  <article class="card border-cor-especial card-largura p-0 m-4 col-12 col-md-4">
    <img src="img/refeitório.jpg" class="card-img-top card-posicao-imagem" alt="...">
    <div class="card-body">
      <h5 class="card-title fonte cor-segunda">Refeitório</h5>
      <p class="card-text">Espaço com ar aconchegante e receptivo, desenvolvido para melhor experiência e partilha nas refeições em conjunto.</p>

    </div>
  </article>
 
  <article class="card border-cor-especial card-largura p-0 m-4 col-12 col-md-4">
    <img src="img/fraldário.jpg" class="card-img-top card-posicao-imagem" alt="...">
    <div class="card-body">
      <h5 class="card-title fonte cor-segunda">Fraldário</h5>
      <p class="card-text">Com maior conforto e segurança, disponibilizante de fraldas e lixeiras para melhor descarte.</p>
   
    </div>
  </article>
 </div>
</section>
</main>

<footer class="bg-light p-3">  <p class="text-success m-0 text-center">contato:<a class="text-success" href="mailto:email@castelinho.com.br">email@castelinho.com.br</a></p>
</footer>
<!-- Modal -->
<div class="modal fade" id="modal-contato" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <dialog class="modal-content">
      <header class="modal-header">
        <h5 class="modal-title fonte cor-segunda" id="exampleModalLabel">Formulário de cadastro para alunos</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </header>
    
      <main class="modal-body">

        <form method="post" action="../Controle/ControleUsuario.php?ACAO=cadastrarUsuario">
          <div class="form-group">
            <label for="formGroupExampleInput">Nome completo</label>
            <input type="text" class="form-control" name='nome' id="formGroupExampleInput" placeholder="Insira seu nome">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">Endereço</label>
            <input type="text" class="form-control" name='endereco' id="exampleFormControlInput1" placeholder="endereço">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">curso</label>
            <input type="text" class="form-control" name='curso_id' id="exampleFormControlInput1" placeholder="curso">
          </div>
        </main> 
        <footer class="modal-footer">
          <button type="button" class="btn btn-light" data-dismiss="modal">Fechar</button>
          <button type="submit" class="btn cor-botao-especial">Enviar</button>
        </footer>
      </form>
      <div class="modal fade" id="modal-contato" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <dialog class="modal-content">
      <header class="modal-header">
        <h5 class="modal-title fonte cor-segunda" id="exampleModalLabel">Formulário de cadastro para professores</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </header>
      <main class="modal-body">
      <div class="modal fade" id="modal-contato" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <dialog class="modal-content">
      <header class="modal-header">
        <h5 class="modal-title fonte cor-segunda" id="exampleModalLabel">Formulário de cadastro para disciplinas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </header>
    
      <main class="modal-body">
  <script src=""></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>

<!DOCTYPE html>
<html>

<head>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
  <style> .fonte{
    font-family: 'Pacifico', cursive;

   }
   .cor-segunda{
      color: darkolivegreen}
   </style>
</head>
<form method="post" action="../Controle/ControleUsuario.php?ACAO=cadastrarU">
          <div class="form-group fonte cor-segunda">
            <label for="formGroupExampleInput">Nome</label>
            <input type="text" class="form-control" name='nome' id="formGroupExampleInput" placeholder="Insira seu nome">
          </div>
          <div class="form-group fonte cor-segunda">
            <label for="exampleFormControlInput1">disciplina</label>
            <input type="text" class="form-control" name='disciplina' id="exampleFormControlInput1" placeholder="disciplina">
          </div>
          </main> 
        <footer class="modal-footer">
          <button type="button" class="btn btn-light fonte cor-segunda" data-dismiss="modal">Fechar</button>
          <button type="submit" class="btn cor-botao-especial fonte cor-segunda">Enviar</button>
        </footer>
      </form>
  </html>
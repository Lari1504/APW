DROP DATABASE SistemaEscolar;
CREATE SCHEMA IF NOT EXISTS SistemaEscolar DEFAULT CHARACTER SET utf8;
USE SistemaEscolar;

CREATE TABLE Curso(
  idCurso INT AUTO_INCREMENT,
  nome VARCHAR(50) NOT NULL,
  descricao VARCHAR(100),
  PRIMARY KEY(idCurso)
)ENGINE=InnoDB;

CREATE TABLE Alunos(
  idAlunos INT AUTO_INCREMENT,
  nome VARCHAR(50) NOT NULL,
  endereco VARCHAR(100),
  curso_id INT,
  PRIMARY KEY (idAlunos),
  FOREIGN KEY (curso_id) REFERENCES curso(idCurso)
)ENGINE=InnoDB;

CREATE TABLE Professores(
  idProfessores INT AUTO_INCREMENT,
  nome VARCHAR(50) NOT NULL,
  disciplina int,
  PRIMARY KEY(idProfessores),
  FOREIGN KEY(disciplina) references Curso(idCurso)
)ENGINE=InnoDB;

INSERT INTO Curso (nome, descricao) VALUES ('Matematica', 'Curso de matemática para alunos do fundamental');
INSERT INTO Curso (nome, descricao) VALUES ('Historia', 'Curso de história para alunos do ensino fundamental');
INSERT INTO Curso (nome, descricao) VALUES ('Ciencias', 'Curso de ciências para alunos do fundamental');
SELECT*FROM Curso;

INSERT INTO Alunos (nome, endereco, curso_id) VALUES ('João', 'Rua A, 12',1);
INSERT INTO Alunos (nome, endereco, curso_id) VALUES ('Maria', 'Rua B, 14',2);
INSERT INTO Alunos (nome, endereco, curso_id) VALUES ('Pedro', 'Rua C, 17',3);
SELECT * FROM Alunos;

INSERT INTO Professores (nome, disciplina) VALUES ('Ana', 1);
INSERT INTO Professores (nome, disciplina) VALUES ('Carlos', 2);
INSERT INTO Professores (nome, disciplina) VALUES ('Mariana', 3);
SELECT*FROM Professores;

SELECT Alunos.nome AS aluno, Professores.nome AS professor, Curso.nome AS curso
FROM Alunos
INNER JOIN Curso ON Alunos.curso_id = Curso.idCurso
INNER JOIN Professores ON Curso.idCurso = Professores.disciplina;
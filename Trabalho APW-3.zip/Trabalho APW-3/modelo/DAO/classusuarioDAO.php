<?php
require_once 'Conexao.php';

class ClassUsuarioDAO
{
    public function cadastrarprofessor(ClassUsuario $cadastrarUsuario)
    {
        try {
            $pdo = Conexao::getInstance();
            $sql = "INSERT INTO Professores (nome, disciplina) VALUES (?,?)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadastrarUsuario->getNome());
            $stmt->bindValue(2, $cadastrarUsuario->getdisciplina());
            $stmt->execute();
            return $stmt->rowCount();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    public function cadastrarcurso(ClassUsuario $cadastrarUsuario)
    {
        try {
            $pdo = Conexao::getInstance();
            $sql = "INSERT INTO Curso (nome, descricao) VALUES (?,?)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadastrarUsuario->getNome());
            $stmt->bindValue(2, $cadastrarUsuario->getdescricao());
            $stmt->execute();
            return $stmt->rowCount();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    public function cadastrar(ClassUsuario $cadastrarUsuario)
    {
        try {
            $pdo = Conexao::getInstance();
            $sql = "INSERT INTO Alunos(nome, endereco, curso_id) VALUES (?,?,?)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadastrarUsuario->getNome());
            $stmt->bindValue(2, $cadastrarUsuario->getEndereco());
            $stmt->bindValue(3, $cadastrarUsuario->getcurso_id());
            $stmt->execute();
            return $stmt->rowCount();
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function buscarUsuario($idUsuario)
    {
        try {
            $usuario = new ClassUsuario();
            $pdo = Conexao::getInstance();
            $sql = "SELECT idAlunos, nome, endereco, curso_id FROM Alunos WHERE idAlunos = :id LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':id', $idUsuario);
            $stmt->execute();
            $usuarioAssoc = $stmt->fetch(PDO::FETCH_ASSOC);

            $usuario->setNome($usuarioAssoc['nome']);
            $usuario->setEndereco($usuarioAssoc['endereco']);
            $usuario->setcurso_id($usuarioAssoc['curso_id']);

            return $usuario;
        } catch (PDOException $ex) {
            return $ex->getMessage();
        }
    }

    public function listarCursos()
    {
        try {
            $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM Curso";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $usuarios;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    public function listarProfessores()
    {
        try {
            $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM Professores";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $usuarios;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
    public function listarAlunos()
    {
        try {
            $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM Alunos";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $usuarios;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }
//     public function alterarUsuario(ClassUsuario $alterarUsuario)
//     {
//         try {
//             $pdo = Conexao::getInstance();
//             $sql = "UPDATE Alunos SET nome=?, endereco=?, curso_id=? WHERE idAlunos=?";
//             $stmt = $pdo->prepare($sql);
//             $stmt->bindValue(1, $alterarUsuario->getNome());
//             $stmt->bindValue(2, $alterarUsuario->getEndereco());
//             $stmt->bindValue(3, $alterarUsuario->getCursoId());
//             $stmt->bindValue(4, $alterarUsuario->getIdUsuario());
//             $stmt->execute();
//             return $stmt->rowCount();
//         } catch (PDOException $ex) {
//             echo $ex->getMessage();
//         }
//     }

//     public function excluirUsuarios($idUsuario)
//     {
//         try {
//             $pdo = Conexao::getInstance();
//             $sql = "DELETE FROM Alunos WHERE idAlunos = :idAlunos";
//             $stmt = $pdo->prepare($sql);
//             $stmt->bindValue(':idAlunos', $idUsuario);
//             $stmt->execute();
//             return $stmt->rowCount();
//         } catch (PDOException $exc) {
//             echo $exc->getMessage();
//         }
//     }
// }

}

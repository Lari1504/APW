<?php
class ClassUsuario
{
    private $IdAluno;
    private $endereco;
    private $nome;
    private $disciplina;
    private $descricao;
    private $curso_id;

    public function getIdAluno()
    {
        return $this->IdAluno;
    }
    public function getdescricao()
    {
        return $this->descricao;
    }
    public function getendereco()
    {
        return $this->endereco;
    }

    public function getNome()
    {
        return $this->nome;
    }
    public function getdisciplina()
    {
        return $this->disciplina;
    }

    public function getcurso_id()
    {
        return $this->curso_id;
    }

    public function setIdAluno($IdAluno)
    {
        $this->IdAluno = $IdAluno;
    }
    public function setendereco($endereco)
    {
        $this->endereco = $endereco;
    }

    public function setNome($nome)
    {
        $this->nome = $nome;
    }
    public function setdisciplina($disciplina)
    {
        $this->disciplina = $disciplina;
    }

    public function setdescricao($descricao)
    {
        $this->descricao = $descricao;
    }
    public function setcurso_id($curso_id)
    {
        $this->curso_id = $curso_id;
    }
}
?>
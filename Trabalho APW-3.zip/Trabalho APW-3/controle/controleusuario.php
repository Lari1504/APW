<?php
require_once '../Modelo/ClassUsuario.php';
require_once '../Modelo/DAO/ClassUsuarioDAO.php';

$id = @$_POST['idex'];
$nome = @$_POST['nome'];
$endereco = @$_POST['endereco'];
$curso_id = @$_POST['curso_id'];
$disciplina = @$_POST['disciplina'];
$descricao = @$_POST['descricao'];
$acao = $_GET['ACAO'];

$novoUsuario = new ClassUsuario();
$novoUsuario->setIdAluno($IdAluno);
$novoUsuario->setNome($nome);
$novoUsuario->setendereco($endereco);
$novoUsuario->setcurso_id($curso_id);
$novoUsuario->setdisciplina($disciplina);
$novoUsuario->setdescricao($descricao);

$classUsuarioDAO = new ClassUsuarioDAO();

switch ($acao) {
    case "cadastrarUsuario":
        $usuario = $classUsuarioDAO->cadastrar($novoUsuario);
        if ($usuario >= 1) {
            header('Location:../index.php?&MSG=Cadastro realizado com sucesso!');
        } else {
            header('Location:../index.php?&MSG=Não foi possível realizar o cadastro!');
        }
        break;

        case "cadastrarU":
            $usuario = $classUsuarioDAO->cadastrarprofessor($novoUsuario);
            if ($usuario >= 1) {
                header('Location:../index.php?&MSG=Cadastro realizado com sucesso!');
            } else {
                header('Location:../index.php?&MSG=Não foi possível realizar o cadastro!');
            }
            break;
            case "cadastro":
                $usuario = $classUsuarioDAO->cadastrarcurso($novoUsuario);
                if ($usuario >= 1) {
                    header('Location:../index.php?&MSG=Cadastro realizado com sucesso!');
                } else {
                    header('Location:../index.php?&MSG=Não foi possível realizar o cadastro!');
                }
                break;

    case 'alterarUsuario':
        $usuario = $classUsuarioDAO->alterar($novoUsuario);
        if ($usuario == 1) {
            header('Location:../index.php?&MSG=Cadastro atualizado com sucesso!');
        } else {
            header('Location:../index.php?&MSG=Não foi possível realizar a atualização!');
        }
        break;

    case "excluirUsuario":
        if (isset($_GET['idex'])) {
            $idUsuario = $_GET['idex'];
            $us = $classUsuarioDAO->excluir($idUsuario);
            if ($us == TRUE) {
                header('Location:../index.php?PAGINA=listarUsuario&MSG=Usuário foi excluído com sucesso!');
            } else {
                header('Location:../index.php?PAGINA=listarUsuario&MSG=Não foi possível realizar a exclusão do usuário!');
            }
        }
        break;

    default:
        break;
}

$usuarios = $classUsuarioDAO->listar();

if ($usuarios) {
    foreach ($usuarios as $usuario) {
        echo "Nome: " . $usuario->getNome() . "<br>";

        if ($usuario instanceof Aluno) {
            echo "Tipo: Aluno<br>";
        }

        if ($usuario instanceof Professor) {
            echo "Tipo: Professor<br>";
            $disciplinas = $usuario->getDisciplinas();
            echo "Disciplinas:<br>";
            foreach ($disciplinas as $disciplina) {
                echo "- " . $disciplina->getNome() . "<br>";
            }
        }

        echo "<br>";
    }
} else {
    echo "Nenhum usuário encontrado.";
}
?>

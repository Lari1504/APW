/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.entidade;
import br.com.controle.Livro;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

/**
 *
 * @author jes73
 */
public class ManterLivro extends DAO{
    public void inserir(Livro l) throws Exception {
    try {
    abrirBanco();
    String query = "INSERT INTO livro(codigo,nome) "
            + "values(null,?)";
    pst=(PreparedStatement) con.prepareStatement(query);
    pst.setString(1, l.getNome());
    pst.execute();
    fecharBanco();
    } catch (Exception e) {
        System.out.println("Erro " + e.getMessage());
    }
    }
    
    //metodo deletar aluno		
 public void deletarLivro(Livro l) throws Exception{
	 abrirBanco();
	 String query = "delete from Livro where codigo=?";
	 pst=(PreparedStatement) con.prepareStatement(query);
	 pst.setInt(1, l.getCodigo());
	 pst.execute();
        JOptionPane.showMessageDialog(null, "livro deletado com sucesso!");
	fecharBanco();
     }
 
 public void PesquisarRegistroLivro(Livro l) throws Exception {
        try {
            abrirBanco();
            String query = "select codigo, nome FROM livro where codigo = ?";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, l.getCodigo());
            ResultSet tr = pst.executeQuery();
            if (tr.next()) {
                l.setCodigo(tr.getInt("codigo"));
                l.setNome(tr.getString("nome"));
                } else {
                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado! ");
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }
 
 // metodo listar 
 public ArrayList<Livro> Pesquisarlivro (String ordenar) throws Exception {
       ArrayList<Livro> Livros = new ArrayList<Livro>();
         try{
         abrirBanco();  
         String query = "select * FROM livro order by codigo "+ordenar;
         pst = (PreparedStatement) con.prepareStatement(query);
         ResultSet tr = pst.executeQuery();
         Livro l ;
         while (tr.next()){               
           l = new Livro();
           l.setCodigo(tr.getInt("codigo"));
           l.setNome(tr.getString("nome"));
           Livros.add(l);
         } 
         fecharBanco();
       }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
     } 
       return Livros;
     }
 public void editarLivro(Livro l) throws Exception {
        abrirBanco();
        //JOptionPane.showMessageDialog(null, a.getNome());
        String query = "UPDATE livro set nome = ? where codigo = ?";
        pst = (PreparedStatement)con.prepareStatement(query);
        pst.setString(1, l.getNome());
        pst.setInt(2, l.getCodigo());
        pst.executeUpdate();
        JOptionPane.showMessageDialog(null, "Livro Alterado com sucesso!");
        fecharBanco();
    }

    public void PesquisarRegistro(Livro l) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.entidade;

import br.com.controle.Alugar_livro;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author contabilidade
 */
public class ManterAlugar_livro extends DAO {

    public void inserir(Alugar_livro al) throws Exception {
        try {
            abrirBanco();
            String query = "INSERT INTO alugar_livro(id_aluno,id_livro) "
                    + "values(?,?)";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, al.getId_aluno());
            pst.setInt(2, al.getId_livro());
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }

    //metodo deletar aluno		
    public void deletarAluno(Alugar_livro al) throws Exception {
        abrirBanco();
        String query = "delete from alugar_livro where id_aluno=?";
        pst = (PreparedStatement) con.prepareStatement(query);
        pst.setInt(1, al.getId_aluno());
        pst.execute();
        JOptionPane.showMessageDialog(null, "Aluno deletado com sucesso!");
        fecharBanco();
    }

    {

    }

    public void PesquisarRegistroAlugar(Alugar_livro al) throws Exception {
        try {
            abrirBanco();
            String query = "select id_aluno, id_livro FROM alugar_livro where codigo = ?";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, al.getId_aluno());
            ResultSet tr = pst.executeQuery();
            if (tr.next()) {
                al.setId_aluno(tr.getInt("id_aluno"));
                al.setId_livro(tr.getInt("id_livro"));
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado! ");
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }
    public ArrayList<Alugar_livro> Pesquisarlivro (String ordenar) throws Exception {
       ArrayList<Alugar_livro> Alugar = new ArrayList<Alugar_livro>();
         try{
         abrirBanco();  
         String query = "SELECT al.id_aluno, a.nome, l.nome as alugado from alugar_livro as al inner join aluno as a on a.codigo = al.id_aluno inner join livro as l on al.id_livro = l.codigo order by al.id_aluno "+ordenar;
         pst = (PreparedStatement) con.prepareStatement(query);
         ResultSet tr = pst.executeQuery();
         Alugar_livro al ;
         while (tr.next()){               
           al = new Alugar_livro();
           al.setId_aluno(tr.getInt("id_aluno"));
           al.setA_nome(tr.getString("nome"));
           al.setL_nome(tr.getString("alugado"));
           Alugar.add(al);
         } 
         fecharBanco();
       }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
     } 
       return Alugar;
     }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

/**
 *
 * @author contabilidade
 */
public class Alugar_livro {
    private int id_aluno;
    private int id_livro;
    private String a_nome;
    private String l_nome;

    public int getId_aluno() {
        return id_aluno;
    }

    public void setId_aluno(int id_aluno) {
        this.id_aluno = id_aluno;
    }

    public int getId_livro() {
        return id_livro;
    }

    public void setId_livro(int id_livro) {
        this.id_livro = id_livro;
    }

    public String getA_nome() {
        return a_nome;
    }

    public void setA_nome(String a_nome) {
        this.a_nome = a_nome;
    }

    public String getL_nome() {
        return l_nome;
    }

    public void setL_nome(String l_nome) {
        this.l_nome = l_nome;
    }
    
    
}
